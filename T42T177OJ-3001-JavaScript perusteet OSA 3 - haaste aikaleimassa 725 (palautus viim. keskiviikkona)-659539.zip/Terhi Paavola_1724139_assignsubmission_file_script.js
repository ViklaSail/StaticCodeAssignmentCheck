var nimi = "Jaakko";

alert(nimi);

nimi = "Saara";

alert(nimi);

var auto = "Toyota";

alert(auto);

var hedelma = "Omena";

alert(hedelma);

var elain = "Kissa";

alert(elain);