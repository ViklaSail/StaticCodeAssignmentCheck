var nimi = "Ville";
var ika= "28";
var ammatti= "Opiskelija";
var pituus="186";

alert(nimi);
alert(ika);
alert(ammatti);
alert(pituus);









