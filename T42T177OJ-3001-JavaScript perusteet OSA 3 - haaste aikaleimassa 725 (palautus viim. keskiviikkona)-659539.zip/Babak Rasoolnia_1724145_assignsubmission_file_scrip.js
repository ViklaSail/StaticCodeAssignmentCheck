var nimi = "Babak";
var ika = "38";
var ammatti = "Opiskelija";
alert(nimi);
alert(ika);
alert(ammatti);