var nimi = "Jouni";

alert(nimi);

var sukunimi = "Laaksonen";

alert(sukunimi);

var asuinpaikka = "Rovaniemi";

alert(asuinpaikka);