var nimi = "jaakko";
var ika = "20";
var ammatti ="huoltomies"

alert(nimi);
alert(ika);
alert(ammatti);



