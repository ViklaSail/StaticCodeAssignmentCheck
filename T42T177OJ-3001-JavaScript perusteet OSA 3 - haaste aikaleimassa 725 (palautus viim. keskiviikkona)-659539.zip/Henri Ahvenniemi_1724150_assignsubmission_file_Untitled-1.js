var tervehdys = "tervehdys";
var halloota = "halloota";
var kuuluu = "mitä kuuluu?";

alert(tervehdys);
alert(halloota);
alert(kuuluu);