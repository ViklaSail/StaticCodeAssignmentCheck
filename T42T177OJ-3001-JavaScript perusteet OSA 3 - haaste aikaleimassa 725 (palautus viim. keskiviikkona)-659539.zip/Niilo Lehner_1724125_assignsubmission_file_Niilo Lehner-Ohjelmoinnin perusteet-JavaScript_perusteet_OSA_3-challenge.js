var greeting = "Hello, ";

var username = "Niilo. ";

var question = "What are you going to do today? ";

alert(greeting + username + question);