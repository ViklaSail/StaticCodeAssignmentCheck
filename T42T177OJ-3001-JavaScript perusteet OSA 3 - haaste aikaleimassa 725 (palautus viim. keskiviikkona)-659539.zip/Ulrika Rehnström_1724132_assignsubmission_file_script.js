var etunimi = "Ulrika";
var sukunimi = "Rehnstrom"
var ika ="48";
var kaupunki = "Loviisa";

alert(etunimi);
alert(sukunimi);
alert(ika);
alert(kaupunki);

 