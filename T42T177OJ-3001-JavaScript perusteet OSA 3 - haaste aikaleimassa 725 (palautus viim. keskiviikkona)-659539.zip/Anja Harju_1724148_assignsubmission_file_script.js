var nimi = "Jaakko";
var ika = "30";
var ammatti = "Opettaja";

alert(nimi);
alert(ika);
alert(ammatti);