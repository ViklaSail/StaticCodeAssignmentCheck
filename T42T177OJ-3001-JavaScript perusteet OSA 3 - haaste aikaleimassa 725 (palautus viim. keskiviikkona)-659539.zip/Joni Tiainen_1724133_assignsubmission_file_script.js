const x = "Moi";
const z = "JS on kivaa!";
const y = "Jep, niin on!";

function alertVars() {
  alert(x);
  alert(z);
  alert(y);
}

alertVars();
