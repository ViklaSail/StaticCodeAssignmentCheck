var nimi = "Teemu";

alert(nimi);

var kaupunki = "Kangasala";
var elintaso = "Varaton";

alert(kaupunki);
alert(elintaso);