var nimi = "Alina";
var day = "Monday";
var color = "red";

alert (nimi);
alert (day);
alert (color);
