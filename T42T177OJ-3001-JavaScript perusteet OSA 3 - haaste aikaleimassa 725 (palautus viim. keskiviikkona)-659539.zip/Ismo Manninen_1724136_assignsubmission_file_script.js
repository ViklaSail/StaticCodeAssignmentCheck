var pituus = "Height = 180";
var paino = "Weight = 100";
var sukupuoli = "Gender = Taisteluhelikopteri";

alert(pituus);
alert(paino);
alert(sukupuoli);